### R code from vignette source 'tmod.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: tmod.Rnw:18-19
###################################################
cairo <- function(name, width, height, ...) grDevices::cairo_pdf(file = paste0(name, ".pdf"), width = width, height = height)


###################################################
### code chunk number 2: tmod.Rnw:22-23
###################################################
png <- function(name, width, height, ...) grDevices::png(file = paste0(name, ".png"), width = width*300, height = height*300)


###################################################
### code chunk number 3: one
###################################################
library(limma)
library(tmod)
t <- data.frame(ID=1:30, 
                group=gsub("\\..*", "", colnames(Egambia)[-c(1:3)]))
e <- new("EList", 
     list(E=as.matrix(Egambia[,-c(1:3)]), genes=Egambia[,c(1:3)], targets=t))


###################################################
### code chunk number 4: two
###################################################
d <- cbind(Intercept=rep(1, 30), TB=rep(c(0,1), each= 15))
f <- eBayes(lmFit(e, d))
tt <- topTable(f, coef=2, number=Inf)
head(tt, 20)


###################################################
### code chunk number 5: two
###################################################
showGene(e$E["20799",], e$targets$group, main=e$genes["20799", "GENE_SYMBOL"])


###################################################
### code chunk number 6: three
###################################################
fg <- tt$GENE_SYMBOL[tt$adj.P.Val < 0.05 & abs( tt$logFC ) > 1]
res <- tmodHGtest(fg=fg, bg=tt$GENE_SYMBOL)
head(res)


###################################################
### code chunk number 7: four
###################################################
l <- topTable(f, coef=2, number=Inf)$GENE_SYMBOL
res2 <- tmodUtest(l)
head( res2 )


###################################################
### code chunk number 8: five
###################################################
evidencePlot(l, "LI.M75")


###################################################
### code chunk number 9: six
###################################################
library(pca3d)
pca <- prcomp(t(e$E), scale.=TRUE)
gr <- e$targets$group
par(mfrow=c(1, 2))
l<-pca2d(pca, group=gr)
legend("topleft", as.character(l$groups),
       pch=l$shapes,
       col=l$colors, bty="n")
l<-pca2d(pca, group=gr, components=3:4)
legend("topleft", as.character(l$groups),
       pch=l$shapes,
       col=l$colors, bty="n")
par(mfrow=c(1, 1))


###################################################
### code chunk number 10: seven
###################################################
o <- order(abs(pca$rotation[,4]), decreasing=TRUE)
l <- e$genes$GENE_SYMBOL[o]
res <- tmodUtest(l)
head(res)


###################################################
### code chunk number 11: eight
###################################################
library(tagcloud)
w <- -log10(res$P.Value)
c <- smoothPalette(res$auc, min=0.5)
tags <- strmultline(res$Title)
tagcloud(tags, weights=w, col=c)


###################################################
### code chunk number 12: nine
###################################################
par(mar=c(1,1,1,1))
o3 <- order(abs(pca$rotation[,3]), decreasing=TRUE)
l3 <- e$genes$GENE_SYMBOL[o3]
res3 <- tmodUtest(l3)
layout(matrix(c(3,1,0,2),2,2,byrow=TRUE),
  widths=c(0.2, 0.8), heights=c(0.8, 0.2))
# note -- PC4 is now x axis!!
l<-pca2d(pca, group=gr, components=4:3)
legend("topleft", 
  as.character(l$groups),
  pch=l$shapes,
  col=l$colors, bty="n")
tagcloud(tags, weights=w, col=c, fvert= 0)
tagcloud(strmultline(res3$Title),
  weights=-log10(res3$P.Value),
  col=smoothPalette(res3$auc, min=0.5),
  fvert=1)


