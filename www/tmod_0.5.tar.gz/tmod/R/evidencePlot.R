.alphacol <- function( x, suff="99" ) {
  x <- col2rgb( x )
  x <- apply( x, 2, function( xx ) paste0( "#", paste( as.hexmode( xx ), collapse= "" ), suff )  )
  x
}

#' Create an evidence plot for a module
#'
#' Create an evidence plot for a module
#'
#'
#' Create an evidence plot for a module
#' @param l sorted list of HGNC gene identifiers
#' @param m character vector of modules for which the plot should be created
#' @param scaled if TRUE, the cumulative sums will be divided by the total sum (default)
#' @param filter if TRUE, genes which are not assigned to any module will be removed
#' @param add if TRUE, the plot will be added to the existing plot
#' @param legend position of the legend. If NULL, no legend will be drawn
#' @seealso tmod-package
#' @examples 
#' fg <- tmodMODULES2GENES[["M127"]]
#' bg <- tmodGENES$ID
#' result <- tmodHGtest( fg, bg )
#' @export
evidencePlot <- function( l, m, scaled= TRUE, filter= FALSE, add= FALSE, legend= "topleft" ) {

  m <- as.character( m )
  if( ! all( m %in% names( tmodMODULES2GENES ) ) ) stop( "No such module" )
  if( filter ) l <- l[ l %in% tmodGENES$ID ]

  n <- length( l )

  x <- sapply( m, function( mm ) l %in% tmodMODULES2GENES[[mm]] )

  if( scaled ) {
    xcs <- apply( x, 2, function( xx ) cumsum( xx ) / sum( xx ) )
  } else {
    xcs <- apply( x, 2, cumsum )
  }

  r <- range( xcs )
  rd <- 0.2 * (r[2]-r[1])
  r[1] <- r[1] - rd

  if( ! add ) {
    plot( NULL, xlim= c( 1, n ), ylim= r, bty="n", xlab="List of genes", ylab=m )
    rect( 0, r[1], n, 0, col= "#eeeeee", border= NA )
  }

  for( i in 1:length( m ) ) { lines( 1:n, xcs[,i], col= i ) }

  for( i in 1:length( m ) ) {
    w <- which( x[,i] )
    segments( w, r[1], w, 0, col= i )
  }

  segments( 0, 0, n, r[2], col= "grey" )

  if( ! is.null( legend ) ) {
    legend( legend, m, col= 1:length( m ), lty= 1, bty= "n" )
  }


}
