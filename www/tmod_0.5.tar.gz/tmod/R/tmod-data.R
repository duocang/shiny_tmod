#' Gene expression module data
#'
#' Gene expression module data
#'
#' These object contain the module annotations (tmodMODULES), gene to
#' module (tmodGENES2MODULES) and module to gene (tmodMODULES2GENES) mappings
#' and a gene list (tmodGENES).
#'
#' tmodMODULES and tmodGENES are data frames, while tmodMODULES2GENES and
#' tmodGENES2MODULES are lists with, respectively, module and gene
#' identifiers as names.
#' @examples
#' # list of first 10 modules
#' tmodMODULES[1:10, ]
#' @name tmod-data
NULL

#' @name tmodGENES
#' @rdname tmod-data
NULL

#' @name tmodGENES2MODULES
#' @rdname tmod-data
NULL

#' @name tmodMODULES
#' @rdname tmod-data
NULL

#' @name tmodMODULES2GENES
#' @rdname tmod-data
NULL
