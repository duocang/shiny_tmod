library(testthat)

test_check("tmod")
