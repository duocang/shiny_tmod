### R code from vignette source 'tmod.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: tmod.Rnw:19-22
###################################################
options(width=60)
options(continue=" ")
cairo <- function(name, width, height, ...) grDevices::cairo_pdf(file = paste0(name, ".pdf"), width = width, height = height)


###################################################
### code chunk number 2: tmod.Rnw:25-26
###################################################
png <- function(name, width, height, ...) grDevices::png(file = paste0(name, ".png"), width = width*300, height = height*300)


###################################################
### code chunk number 3: twoA
###################################################
library(limma)
library(tmod)
design <- cbind(Intercept=rep(1, 30), TB=rep(c(0,1), each= 15))
E <- as.matrix(Egambia[,-c(1:3)])
fit <- eBayes( lmFit(E, design))
tt <- topTable(fit, coef=2, number=Inf, 
  genelist=Egambia[,1:3] )

head(tt, 10)


###################################################
### code chunk number 4: two
###################################################
group <- rep( c("CTRL", "TB"), each=15)
showGene(E["20799",], group,
  main=Egambia["20799", "GENE_SYMBOL"])


###################################################
### code chunk number 5: three
###################################################
fg <- tt$GENE_SYMBOL[tt$adj.P.Val < 0.05 & abs( tt$logFC ) > 1]
res <- tmodHGtest(fg=fg, bg=tt$GENE_SYMBOL)
res


###################################################
### code chunk number 6: four
###################################################
l    <- tt$GENE_SYMBOL
res2 <- tmodUtest(l)
head(res2)
nrow(res2)


###################################################
### code chunk number 7: fourB
###################################################
l    <- tt$GENE_SYMBOL
res2 <- tmodCERNOtest(l)
head( res2 )


###################################################
### code chunk number 8: five
###################################################
evidencePlot(l, "LI.M75")


###################################################
### code chunk number 9: fiveB
###################################################
l    <- tt$GENE_SYMBOL
res2 <- tmodUtest(l, mset="all")
head( res2 )


###################################################
### code chunk number 10: six
###################################################
library(pca3d)
pca <- prcomp(t(E), scale.=TRUE)
par(mfrow=c(1, 2))
l<-pca2d(pca, group=group)
cols <- as.character(l$colors)
legend("topleft", as.character(l$groups),
       pch=l$shapes,
       col=cols, bty="n")
l<-pca2d(pca, group=group, components=3:4)
legend("topleft", as.character(l$groups),
       pch=l$shapes,
       col=cols, bty="n")
par(mfrow=c(1, 1))


###################################################
### code chunk number 11: seven
###################################################
o <- order(abs(pca$rotation[,4]), decreasing=TRUE)
l <- Egambia$GENE_SYMBOL[o]
res <- tmodUtest(l)
head(res)


###################################################
### code chunk number 12: eight
###################################################
library(tagcloud)
w <- -log10(res$P.Value)
c <- smoothPalette(res$AUC, min=0.5)
tags <- strmultline(res$Title)
tagcloud(tags, weights=w, col=c)


###################################################
### code chunk number 13: nine
###################################################
par(mar=c(1,1,1,1))
o3 <- order(abs(pca$rotation[,3]), decreasing=TRUE)
l3 <- Egambia$GENE_SYMBOL[o3]
res3 <- tmodUtest(l3)
layout(matrix(c(3,1,0,2),2,2,byrow=TRUE),
  widths=c(0.3, 0.7), heights=c(0.7, 0.3))
# note -- PC4 is now x axis!!
l<-pca2d(pca, group=group, components=4:3)
cols <- as.character(l$colors)
legend("topleft", 
  as.character(l$groups),
  pch=l$shapes,
  col=cols, bty="n")
tagcloud(tags, weights=w, col=c, fvert= 0)
tagcloud(strmultline(res3$Title),
  weights=-log10(res3$P.Value),
  col=smoothPalette(res3$AUC, min=0.5),
  fvert=1)


###################################################
### code chunk number 14: nineB
###################################################
tmodPCA(pca, 
  genes=Egambia$GENE_SYMBOL, 
  components=3:4,
  plot.params=list(group=group))


###################################################
### code chunk number 15: ten
###################################################
res <- tmodUtest(tt$GENE_SYMBOL, qval=Inf)
gstest <- function(x) {
  sel <- tt$GENE_SYMBOL %in% tmodMODULES2GENES[[x]]
  geneSetTest(sel, tt$logFC)
}
gst <- sapply(res$ID, gstest)


###################################################
### code chunk number 16: eleven
###################################################
plot(res$P.Value, gst, 
  log="xy", pch=19,
  col="#33333366",
  xlab="P Values from tmod", 
  ylab="P Values from geneSetTest")
abline(0,1)
abline(h=0.01, col="grey")
abline(v=0.01, col="grey")


###################################################
### code chunk number 17: exmset
###################################################
mymset <- list(
  MODULES=data.frame(ID=c("A", "B"),
                       Title=c("A title", 
                                      "B title")),
  GENES=data.frame(ID=c( "G1", "G2", "G3", "G4" )),
  MODULES2GENES=list(
    A=c("G1", "G2"),
    B=c("G3", "G4"))
)


###################################################
### code chunk number 18: msigdbparse1 (eval = FALSE)
###################################################
## msig <- tmodImportMsigDB("msigdb_v5.0.xml")


###################################################
### code chunk number 19: msigdb6 (eval = FALSE)
###################################################
## res <- tmodCERNOtest(tt$GENE_SYMBOL, mset=msig )
## head(res)


###################################################
### code chunk number 20: msigdb7 (eval = FALSE)
###################################################
## sel <- msig$MODULES$Category == "H"
## 
## tmodCERNOtest(tt$GENE_SYMBOL, 
##   modules=msig$MODULES$ID[sel],
##   mset=msig )


###################################################
### code chunk number 21: msigdb1 (eval = FALSE)
###################################################
## library(XML)
## foo  <- xmlParse( "/home/january/Projects/R/pulemodule/vignette/msigdb_v5.0.xml" )
## foo2 <- xmlToList(foo)


###################################################
### code chunk number 22: msigdb2 (eval = FALSE)
###################################################
## path1 <- foo2[[1]]
## class(path1)


###################################################
### code chunk number 23: msigdb2b (eval = FALSE)
###################################################
## names(path1)


###################################################
### code chunk number 24: msigdb3 (eval = FALSE)
###################################################
## orgs <- sapply(foo2, function(x) x["ORGANISM"])
## unique(orgs)
## 
## foo3 <- foo2[ orgs == "Homo sapiens" ]
## foo3 <- foo3[ ! sapply(foo3, is.null) ]


###################################################
### code chunk number 25: msigdb4 (eval = FALSE)
###################################################
## msig <- list()
## 
## msig$MODULES <- t(sapply(foo3, 
##   function(x) 
##     x[ c("SYSTEMATIC_NAME", "STANDARD_NAME", "CATEGORY_CODE", "SUBCATEGORY_CODE") ])) 
## colnames(msig$MODULES) <- c( "ID", "Title", "Category", "Subcategory" )
## rownames(msig$MODULES) <- msig$MODULES[,"ID"]
## msig$MODULES <- data.frame(msig$MODULES, stringsAsFactors=FALSE)


###################################################
### code chunk number 26: msigdb5 (eval = FALSE)
###################################################
## msig$MODULES2GENES <- lapply(foo3, 
##   function(x) strsplit( x["MEMBERS_SYMBOLIZED"], "," )[[1]])
## names(msig$MODULES2GENES) <- msig$MODULES$ID
## 
## msig$GENES <- data.frame( ID=unique(unlist(msig$MODULES2GENES)))


###################################################
### code chunk number 27: wpex1
###################################################
download.file(
"http://www.wikipathways.org//wpi/batchDownload.php?species=Homo%20sapiens&fileType=txt", 
  destfile="human.zip")
files <- unzip( "human.zip", list=T)

files$ID    <- gsub( ".*_(WP[0-9]*)_.*", "\\1", files$Name )
files$Title <- gsub( "(.*)_WP[0-9]*_.*", "\\1", files$Name )


###################################################
### code chunk number 28: wpex2
###################################################
library(org.Hs.eg.db)
p2GENES <- sapply( files$Name, function(fn) {
  foo <- read.csv( unz( "human.zip", 
  filename= fn ), sep="\t" )
  ids <- foo$Identifier[ foo$Identifier %in% ls( org.Hs.egSYMBOL ) ]
  unique(unlist(mget(as.character(ids), org.Hs.egSYMBOL)))
})

names(p2GENES) <- files$ID


###################################################
### code chunk number 29: wpex3
###################################################
pathways <- data.frame( ID=files$ID, 
  Title=files$Title,
  stringsAsFactors=FALSE )
pathways$N <- sapply(p2GENES, length)
pathways$URL <- 
  paste0("http://www.wikipathways.org/index.php/Pathway:",
  pathways$ID )
sel <- pathways$N > 4
pathways <- pathways[ sel, ]


###################################################
### code chunk number 30: wpex4
###################################################
GENES <- data.frame( ID=unique(unlist(p2GENES)))

Hspaths <- list( MODULES=pathways, 
      MODULES2GENES=p2GENES, 
      GENES=GENES )


###################################################
### code chunk number 31: wpex5
###################################################
tmodCERNOtest(tt$GENE_SYMBOL, mset=Hspaths)


###################################################
### code chunk number 32: wpex6
###################################################
sel <- grep( "Interferon", 
  Hspaths$MODULES$Title, ignore.case=T )
tmodCERNOtest(tt$GENE_SYMBOL, mset=Hspaths, 
  modules=Hspaths$MODULES$ID[sel]) 


