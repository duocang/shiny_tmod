
## annotated PCA
.cerno2tagcloud <- function( res, filter=TRUE, simplify=TRUE, ... ) {
  res <- res[ ! res$Title %in% c( "TBA", "Undetermined", "Not Determined"), ]

  res$Title <- gsub( " \\([IV]*\\)$", "", res$Title )
  res <- res[ ! duplicated( res$Title ), ]

  if(nrow(res) == 0 ) {
    plot.new()
  } else {
    print(res)
    #tagcloud(strmultline(res$Title), weights=-log10(res$P.Value), col=smoothPalette(res$AUC, min=0.5), ...)
    tagcloud(strmultline(res$Title), weights=res$AUC, col=smoothPalette(-log10(res$P.Value), max=5), ceiling=5, ...)
  }
}



#' PCA plot annotated with tmod
#'
#' PCA plot annotated with tmod
#'
#' PCA plot annotated with tmod. 
#'
#' There are three types of plots that can be generated (parameter "mode"):
#' simple, leftbottom and cross. In the "simple" mode, two enrichments are
#' run, on on each component, sorted by absolute loadings of the PCA
#' components.
#' Both "leftbottom" and "cross" run two enrichment analyses on each component,
#' one on the loadings sorted from lowest to largest, and one on the loadings
#' sorted from largetst to lowest. Thus, two tag clouds are displayed per
#' component. In the "leftbottom" mode, the tag clouds are displayed to the
#' left and below the PCA plot. In the "cross" mode, the tag clouds are
#' displayed on each of the four sides of the plot.
#'
#' By default, the plotting function is pca2d from the pca3d package. Any
#' additional parametrs for pca2d can be passed on using the plot.params
#' parameter. You can define your own function instead of pca2d, however, mind
#' that in any case, there will be two parameters passed to it on the first
#' two positions: pca and components, named "pca" and "components"
#' respectively.
#' @param pca Object returned by prcomp or a matrix of PCA coordinates. In the latter case, a
#' loading matrix must be provided separately.
#' @param genes A character vector with gene identifiers
#' @param tmodfunc Name of the tmod enrichment test function to use. Either
#' @param plotfunc Function for plotting the PCA plot. See Details
#' @param plot.params A list of parameters to be passed to the plotting function. See
#' Details
#' @param mode Type of the plot to generate; see Details.
#' tmodCERNOtest or tmodUtest (tmodHGtest is not suitable)
#' @param integer vector of length two: components which components to show on the plot. Must be smaller than the number of columns in pca.
#' @param filter Whether "uninteresting" modules (with no annotation)
#' should be removed from the tag cloud
#' @param simplify Whether the names of the modules should be simplified
#' @param ... Any further parameters passed to the tmod test function
#' @importFrom tagcloud tagcloud strmultline
#' @importFrom pca3d pca2d
#' @return A list containing the plot legend as well as the calculated enrichments
#' @export
tmodPCA <- function( pca, loadings=NULL, genes, 
                     tmodfunc="tmodCERNOtest", 
                     plotfunc=pca2d,
                     mode="simple", 
                     components=c(1,2), 
                     plot.params=NULL,
                     filter=TRUE, simplify=TRUE, ... ) {

  mode <- match.arg( mode, c( "simple", "leftbottom", "cross" ) )
  tmodfunc <- match.arg(tmodfunc, c( "tmodCERNOtest", "tmodUtest" ))
  tfunc <- switch(tmodfunc, tmodCERNOtest=tmodCERNOtest, tmodUtest=tmodUtest)

  if( mode == "simple" ) { 
    layout(matrix(c(2,3,
                    4,1),2,2,byrow=TRUE), 
           widths=c(0.3, 0.7), heights=c(0.7, 0.3))
  } else if( mode == "leftbottom" ) {
    layout(matrix( c(4, 5, 5, 
                     3, 5, 5, 
                     6, 1, 2), 3, 3, byrow=TRUE), 
           widths=rep(1/3, 3), heights=rep(1/3, 3))
  } else if( mode == "cross" ) {
    layout(matrix( c( 6, 4, 0,
                      1, 5, 2,
                      0, 3, 0), 3, 3, byrow=TRUE), 
           widths=c( 1/4, 1/2, 1/4), heights=c( 1/4, 1/2, 1/4 ))
  }

  oldpar <- par( mar=c( 1, 2, 0, 0 ) )
  on.exit( par(oldpar) )

  cc <- components

  ret <- list()

  if( mode == "simple" ) {
    ids <- paste0( "Component", cc )
    res <- tfunc( genes[ order( abs( pca$rotation[,cc[1]] ), decreasing=T ) ], ... )
    .cerno2tagcloud( res, filter=filter, simplify=simplify )
    ret[[ids[1]]] <- res

    res <- tfunc( genes[ order( abs( pca$rotation[,cc[2]] ), decreasing=T ) ], ... )
    .cerno2tagcloud( res, filter=filter, simplify=simplify, fvert=1 )
    ret[[ids[2]]] <- res
  } else {
    ids <- paste0( "Component", cc )
    ids <- c( paste0(ids[1], c(".left", ".right")), paste0(ids[2], ".bottom", ".top"))

    fverts <- c( 0, 0, 1, 1 )
    if(mode == "cross") fverts <- c( 0, 0, 0, 0 )
    
    res <- tfunc( genes[ order( pca$rotation[,cc[1]], decreasing=F ) ], ... )
    .cerno2tagcloud( res, filter=filter, simplify=simplify, fvert=fverts[1], algorithm="fill" )
    ret[[ids[1]]] <- res
    res <- tfunc( genes[ order( pca$rotation[,cc[1]], decreasing=T ) ], ... )
    .cerno2tagcloud( res, filter=filter, simplify=simplify, fvert=fverts[2], algorithm="fill" )
    ret[[ids[2]]] <- res
    res <- tfunc( genes[ order( pca$rotation[,cc[2]], decreasing=F ) ], ... )
    .cerno2tagcloud( res, filter=filter, simplify=simplify, fvert=fverts[3], algorithm="fill" )
    ret[[ids[3]]] <- res
    res <- tfunc( genes[ order( pca$rotation[,cc[2]], decreasing=T ) ], ... )
    .cerno2tagcloud( res, filter=filter, simplify=simplify, fvert=fverts[4], algorithm="fill" )
    ret[[ids[4]]] <- res
  }

  plot.params <- c(list(pca=pca, components=components), plot.params)

  ret$legend <- do.call(plotfunc, plot.params )
  plot.new()

  return(invisible(ret))
}
