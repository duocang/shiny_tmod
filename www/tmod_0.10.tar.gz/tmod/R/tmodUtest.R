## clean up modules requested 
.getmodules <- function(modules=NULL, mset="all") {

  if( is.null( modules ) ) modules <- tmodMODULES$ID

  mset <- match.arg( mset, c( "all", unique( tmodMODULES$SourceID )) )

  if( mset != "all" ) { 
    modules <- modules[ tmodMODULES[modules,]$SourceID == mset ]
  }

  modules
}


## this is the function that does the actual testing and concocting the
## results
.tmodTest <- function( mod.test, post.test=NULL, modules=NULL, qval= 0.05, order.by= "pval", mset="LI"  ) {

  modules <- .getmodules(modules, mset)

  order.by <- match.arg( order.by, c( "pval", "none", "auc" ) )

  # --------------------------------------------------------------
  #                  The actual test
  ret <- data.frame(t( sapply( modules, mod.test ) ), stringsAsFactors=FALSE)
  if( ! is.null( post.test ) ) ret <- post.test( ret )
  # --------------------------------------------------------------

  ret <- data.frame( ID= modules, 
                     Title=tmodMODULES[modules,]$Module.title,
                     ret, stringsAsFactors=FALSE )
  ret$adj.P.Val <- p.adjust( ret$P.Value, method= "fdr" )
  rownames(ret) <- ret$ID
  ret <- ret[ ret$adj.P.Val < qval,, drop= FALSE ]

  if( order.by == "pval" ) ret <- ret[ order( ret$P.Value ), ]
  if( order.by == "auc" )  ret <- ret[ order( ret$AUC ), ]
  class( ret ) <- c( "tmodReport", class( ret ) )
  ret

}


#' Perform a statistical test of module expression
#'
#' Perform a statistical test of module expression
#'
#' Performs a test on either on an ordered list of genes (tmodUtest,
#' tmodCERNOtest) or on two groups of genes (tmodHGtest).
#' tmodUtest is a U test on ranks of genes that are contained in a module.
#'
#' tmodCERNOtest is also a nonparametric test working on gene ranks, but it
#' originates from Fisher's combined probability test. This test weights
#' genes with lower ranks more, the resulting p-values better correspond to
#' the observed effect size. In effect, modules with small effect but many
#' genes get higher p-values than in case of the U-test.
#'
#' tmodHGtest is simply a hypergeometric test.
#'
#' @return A data frame with module names, additional statistic (like
#' enrichment), P value and FDR q-value (P value corrected for multiple
#' testing using the p.adjust function and Benjamini-Hochberg correction.
#' @param l sorted list of HGNC gene identifiers
#' @param modules optional list of modules for which to make the test
#' @param qval Threshold FDR value to report
#' @param order.by Order by P value ("pval") or none ("none")
#' @param filter Remove gene names which have no module assignments
#' @param mset Which module set to use. "LI", "DC" or "all" (default: LI)
#' @param useR use the R \code{wilcox.test} function; slow, but with exact p-values for small samples
#' @seealso tmod-package
#' @examples 
#' fg <- tmodMODULES2GENES[["LI.M127"]]
#' bg <- tmodGENES$ID
#' result <- tmodHGtest( fg, bg )
#' @export
tmodUtest <- function( l, modules=NULL, qval= 0.05, order.by= "pval", filter= FALSE, mset="LI", useR=FALSE ) {

  # prepare the variables specific to that test
  l <- as.character( unique( l ) )

  if( sum( l %in% tmodGENES$ID ) == 0 ) {
    warning( "No genes in l match genes in tmodGENES" )
    return(NULL)
  }

  if( filter ) l <- l[ l %in% tmodGENES$ID ]
  N <- length( l )


  # set up the test function
  mod.test <- function( m ) {
    x <- l %in% tmodMODULES2GENES[[m]]
    pos <- which( x )
    N1 <- length( pos )
    R1 <- sum(pos)
    if( !useR ) return( c( N1=N1, R1=R1 ) )

    # if useR:
    neg <- which( ! x )
    AUC <- sum(1 - pos/N)/N1

    if( N1 == 0 ) {
      ret <- c(U=NA, N1=NA, AUC=NA, P.Value=1)  
    } else {
      tt <- wilcox.test( pos, neg, alternative= "less" )
      ret <- c( U=unname(tt$statistic), N1=N1, AUC=AUC, P.Value=tt$p.value )
    }
    ret
  }
  # homebrew U test; post.test function
  post.test <- function( ret ) {
    if(useR) {
      return(ret)
    }

    N1 <- ret$N1
    N2 <- N - ret$N1
    R1 <- ret$R1
    U  <- N1*N2+N1*(N1+1)/2-R1
    Mu <- N1*N2/2
    Su <- sqrt( N1*N2*(N+1)/12 )
    z  <- (-abs(U-Mu)+0.5)/Su
    P  <- pnorm(z)
    AUC <- U/(N1*N2)
    return( data.frame(U=U, N1=N1, AUC=AUC, P.Value=P, stringsAsFactors=FALSE) )
  }

  ret <- .tmodTest( mod.test, post.test, modules=modules, qval=qval, order.by=order.by, mset=mset )
  ret
}

#' @name tmodUtest
#' @export
tmodCERNOtest <- function( l, modules=NULL, qval= 0.05, order.by= "pval", filter= FALSE, mset="LI", useR=FALSE ) {

  # prepare the variables specific to that test
  l <- as.character( unique( l ) )

  if( sum( l %in% tmodGENES$ID ) == 0 ) {
    warning( "No genes in l match genes in tmodGENES" )
    return(NULL)
  }

  if( filter ) l <- l[ l %in% tmodGENES$ID ]
  N <- length( l )

  # set up the test function
  mod.test <- function( m ) {
    x <- l %in% tmodMODULES2GENES[[m]]
    N1 <- sum(x)

    ranks <- c(1:N)[x]
    cerno <- -2 * sum( log(ranks/N) )
    cES <- cerno/(2*N1)
    ret <- c(cerno=cerno, N1=N1, R1=sum(ranks), cES=cES, P.Value=1)
    ret
  }

  post.test <- function(ret) {
    ret <- data.frame(ret, stringsAsFactors=FALSE)
    N1 <- ret$N1
    N2 <- N - N1
    R1 <- ret$R1
    U  <- N1*N2+N1*(N1+1)/2-R1
    ret$AUC <- U/(N1*N2)
    ret <- ret[ , c( "cerno", "N1", "AUC", "cES" ) ]
    ret$P.Value= pchisq(ret$cerno, 2*ret$N1, lower.tail=FALSE)
    ret
  }

  ret <- .tmodTest( mod.test, post.test, modules=modules, qval=qval, order.by=order.by, mset=mset )
  ret
}


#' Calculate AUC
#'
#' Calculate AUC
#'
#' tmodAUC calculates the AUC and U statistics. The main purpose of this
#' function is the use in randomization tests. While tmodCERNOtest and
#' tmodUtest both calculate, for each module, the enrichment in a single
#' sorted list of genes, tmodAUC takes any number of such sorted lists. Or,
#' actually, sortings -- vectors with ranks of the genes in each replicate.

#' Note that the input for this function
#' is different from tmodUtest and related functions: the ordering of l
#' and the matrix ranks does not matter, as long as the matrix ranks
#' contains the actual rankings. Each column in the ranks matrix is treated as
#' a separate sample.
#'
#' @return A matrix with the same number of columns as "ranks" and as many
#' rows as there were modules to be tested.
#' @param l List of gene names corresponding to rows from the ranks matrix
#' @param ranks a matrix with ranks, where columns correspond to samples
#' and rows to genes from the l list
#' @param modules optional list of modules for which to make the test
#' @param filter Remove gene names which have no module assignments
#' @param remove.dups Remove duplicate gene names in l and corresponding
#' rows from ranks
#' @param recalculate.ranks Filtering and removing duplicates will also
#' remove ranks, so that they should be recalculated. Use FALSE if you don't
#' want this behavior. If unsure, stay with TRUE
#' @param mset Which module set to use. "LI", "DC" or "all" (default: LI)
#' @seealso tmod-package
#' @examples 
#' l <- tmodGENES$ID
#' ranks <- 1:length(l)
#' tmodAUC(l, ranks)
#' @export
tmodAUC <- function( l, ranks, modules=NULL, remove.dups=TRUE, recalculate.ranks=TRUE, filter=FALSE, mset="LI" ) {

  # prepare the variables 
  if(is.vector(ranks)) ranks <- matrix(ranks, ncol=1)

  l <- as.character( l )
 
  if(remove.dups) {
    dups <- duplicated(l)
    l <- l[!dups]
    ranks <- ranks[!dups,,drop=FALSE]
  }
 
  if( sum( l %in% tmodGENES$ID ) == 0 ) {
    warning( "No genes in l match genes in tmodGENES" )
    return(NULL)
  }
 
  if( filter ) {
    sel <- l %in% tmodGENES$ID
    l <- l[ sel ]
    ranks <- ranks[sel,,drop=F]
  }
 
  N <- length( l )
  if(N != nrow(ranks)) stop("l and ranks have different sizes!")
 
  modules <- .getmodules(modules, mset)

  if(recalculate.ranks) {
    ranks <- apply(ranks, 2, rank)
  }

  ret <- sapply(modules, function(m) {
    x <- l %in% tmodMODULES2GENES[[m]]
    N1 <- sum(x)
    R1 <- apply( ranks[x,,drop=F], 2, sum )
    c( N1, R1 )
  })

  ret <- t(ret)
  N1 <- ret[,1]
  ret <- ret[,-1,drop=F]

  N2 <- N - N1
  AUC <- apply(ret, 2, function(r1) 1+(N1*(N1+1)/2-r1)/(N1*N2))

  AUC
}


#' @name tmodUtest
#' @export
tmodHGtest <- function( fg, bg, modules=NULL, qval= 0.05, order.by= "pval", filter= FALSE, mset="LI" ) {

  fg <- as.character( unique( fg ) )
  bg <- as.character( unique( bg ) )
  bg <- setdiff( bg, fg )
  if( length(bg) == 0 ) stop( "Insufficient bg" )

  if( sum( bg %in% tmodGENES$ID ) == 0 ) {
    warning( "No genes in bg match any of the genes in the tmodGENES" )
  }

  if( sum( fg %in% tmodGENES$ID ) == 0 ) {
    warning( "No genes in fg match any of the genes in the tmodGENES" )
    return( NULL )
  }

  if( filter ) {
    fg <- fg[ fg %in% tmodGENES$ID ]
    bg <- bg[ bg %in% tmodGENES$ID ]
  }


  tot <- unique( c( fg, bg ) )
  n   <- length( tot )
  k   <- length( fg )

  mod.test <- function( m ) {
    mg <- tmodMODULES2GENES[[m]]
    q <- sum( fg %in% mg ) 
    m <- sum( tot %in% mg )

    if( m == 0 ) { E <- NA } 
    else { E <- (q/k)/(m/n) }

    if( q == 0 || m == 0 ) return( c( b=q, B=m, n=k, N=n, E=E, P.Value=1 ) )

    pv <- phyper( q-1, m, n-m, k, lower.tail= FALSE )
    c( b=q, B=m, n=k, N=n, E=E, P.Value=pv )
  }


  ret <- .tmodTest( mod.test, NULL, modules=modules, qval=qval, order.by=order.by, mset=mset )
  ret
}
