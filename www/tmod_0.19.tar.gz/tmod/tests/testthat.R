library(testthat)
library(tmod)

test_check("tmod")
