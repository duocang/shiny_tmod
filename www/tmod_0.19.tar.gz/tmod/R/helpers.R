# helper wrappers around sprintf
.catf <- function( ... ) cat( sprintf( ... ) )
.printf <- function( ... ) print( sprintf( ... ) )


