# this is the function that does the actual testing and concocting the
# results
.tmodTest <- function( mod.test, post.test=NULL, modules=NULL, qval= 0.05, order.by= "pval", mset="LI"  ) {

  if( is.null( modules ) ) modules <- tmodMODULES$ID

  mset <- match.arg( mset, c( "all", unique( tmodMODULES$SourceID )) )

  if( mset != "all" ) { 
    modules <- modules[ tmodMODULES[modules,]$SourceID == mset ]
  }

  order.by <- match.arg( order.by, c( "pval", "none" ) )

  ret <- data.frame(t( sapply( modules, mod.test ) ), stringsAsFactors=FALSE)
  if( ! is.null( post.test ) ) ret <- post.test( ret )

  ret <- data.frame( ID= modules, 
                     Title=tmodMODULES[modules,]$Module.title,
                     ret, stringsAsFactors=FALSE )
  ret$adj.P.Val <- p.adjust( ret$P.Value, method= "fdr" )
  rownames(ret) <- ret$ID
  ret <- ret[ ret$adj.P.Val < qval,, drop= FALSE ]

  if( order.by == "pval" ) ret <- ret[ order( ret$P.Value ), ]
  class( ret ) <- c( "tmodReport", class( ret ) )
  ret

}


#' Perform a statistical test of module expression
#'
#' Perform a statistical test of module expression
#'
#' Performs a test on either on an ordered list of genes (tmodUtest,
#' tmodCERNOtest) or on two groups of genes (tmodHGtest).
#' tmodUtest is a U test on ranks of genes that are contained in a module.
#'
#' tmodCERNOtest is also a nonparametric test working on gene ranks, but it
#' originates from Fisher's combined probability test. This test weights
#' genes with lower ranks more, the resulting p-values better correspond to
#' the observed effect size. In effect, modules with small effect but many
#' genes get higher p-values than in case of the U-test.
#'
#' tmodHGtest is simply a hypergeometric test.
#'
#' @return A data frame with module names, additional statistic (like
#' enrichment), P value and FDR q-value (P value corrected for multiple
#' testing using the p.adjust function and Benjamini-Hochberg correction.
#' @param l sorted list of HGNC gene identifiers
#' @param modules optional list of modules for which to make the test
#' @param cerno If TRUE, use the CERNO test
#' @param qval Threshold FDR value to report
#' @param order.by Order by P value ("pval") or none ("none")
#' @param filter Remove gene names which have no module assignments
#' @param mset Which module set to use. "LI", "DC" or "all"
#' @param useR use the R \code{wilcox.test} function; slow, but with exact p-values for small samples
#' @seealso tmod-package
#' @examples 
#' fg <- tmodMODULES2GENES[["LI.M127"]]
#' bg <- tmodGENES$ID
#' result <- tmodHGtest( fg, bg )
#' @export
tmodUtest <- function( l, modules=NULL, qval= 0.05, order.by= "pval", filter= FALSE, mset="LI", useR=FALSE ) {

  # prepare the variables specific to that test
  l <- as.character( unique( l ) )

  if( sum( l %in% tmodGENES$ID ) == 0 ) {
    warning( "No genes in l match genes in tmodGENES" )
    return(NULL)
  }

  if( filter ) l <- l[ l %in% tmodGENES$ID ]
  N <- length( l )


  # set up the test function
  mod.test <- function( m ) {
    x <- l %in% tmodMODULES2GENES[[m]]
    pos <- which( x )
    N1 <- length( pos )
    R1 <- sum(pos)
    if( !useR ) return( c( N1=N1, R1=R1 ) )

    # if useR:
    neg <- which( ! x )
    AUC <- sum(1 - pos/N)/N1

    if( N1 == 0 ) {
      ret <- c(U=NA, N1=NA, AUC=NA, P.Value=1)  
    } else {
      tt <- wilcox.test( pos, neg, alternative= "less" )
      ret <- c( U=unname(tt$statistic), N1=N1, AUC=AUC, P.Value=tt$p.value )
    }
    ret
  }
  # homebrew U test; post.test function
  post.test <- function( ret ) {
    if(useR) {
      return(ret)
    }

    N1 <- ret$N1
    N2 <- N - ret$N1
    R1 <- ret$R1
    U  <- N1*N2+N1*(N1+1)/2-R1
    Mu <- N1*N2/2
    Su <- sqrt( N1*N2*(N+1)/12 )
    z  <- (-abs(U-Mu)+0.5)/Su
    P  <- pnorm(z)
    AUC <- U/(N1*N2)
    return( data.frame(U=U, N1=N1, AUC=AUC, P.Value=P, stringsAsFactors=FALSE) )
  }

  ret <- .tmodTest( mod.test, post.test, modules=modules, qval=qval, order.by=order.by, mset=mset )
  ret
}

#' @name tmodUtest
#' @export
tmodCERNOtest <- function( l, modules=NULL, qval= 0.05, order.by= "pval", filter= FALSE, mset="LI", useR=FALSE ) {

  # prepare the variables specific to that test
  l <- as.character( unique( l ) )

  if( sum( l %in% tmodGENES$ID ) == 0 ) {
    warning( "No genes in l match genes in tmodGENES" )
    return(NULL)
  }

  if( filter ) l <- l[ l %in% tmodGENES$ID ]
  N <- length( l )


  # set up the test function
  mod.test <- function( m ) {
    x <- l %in% tmodMODULES2GENES[[m]]
    N1 <- sum(x)

    ranks <- c(1:N)[x]
    cerno <- -2 * sum( log(ranks/N) )
    cES <- cerno/(2*N1)
    ret <- c(cerno=cerno, N1=N1, cES=cES, P.Value=1)
    ret
  }

  post.test <- function(ret) {
    ret <- data.frame(ret, stringsAsFactors=FALSE)
    ret$P.Value= pchisq(ret$cerno, 2*ret$N1, lower.tail=FALSE)
    ret
  }


  ret <- .tmodTest( mod.test, post.test, modules=modules, qval=qval, order.by=order.by, mset=mset )
  ret
}

#' @name tmodUtest
#' @export
tmodHGtest <- function( fg, bg, modules=NULL, qval= 0.05, order.by= "pval", filter= FALSE, mset="LI" ) {

  fg <- as.character( unique( fg ) )
  bg <- as.character( unique( bg ) )
  bg <- setdiff( bg, fg )
  if( length(bg) < 1 ) stop( "Insufficient bg" )

  if( sum( bg %in% tmodGENES$ID ) == 0 ) {
    warning( "No genes in bg match any of the genes in the tmodGENES" )
  }

  if( sum( fg %in% tmodGENES$ID ) == 0 ) {
    warning( "No genes in fg match any of the genes in the tmodGENES" )
    return( NULL )
  }

  if( filter ) {
    fg <- fg[ fg %in% tmodGENES$ID ]
    bg <- bg[ bg %in% tmodGENES$ID ]
  }


  tot <- unique( c( fg, bg ) )
  n   <- length( tot )
  k   <- length( fg )

  mod.test <- function( m ) {
    mg <- tmodMODULES2GENES[[m]]
    q <- sum( fg %in% mg ) 
    m <- sum( tot %in% mg )

    if( m == 0 ) { E <- NA } 
    else { E <- (q/k)/(m/n) }

    if( q == 0 || m == 0 ) return( c( b=q, B=m, n=k, N=n, E=E, P.Value=1 ) )

    pv <- phyper( q-1, m, n-m, k, lower.tail= FALSE )
    c( b=q, B=m, n=k, N=n, E=E, P.Value=pv )
  }


  ret <- .tmodTest( mod.test, NULL, modules=modules, qval=qval, order.by=order.by, mset=mset )
  ret
}
